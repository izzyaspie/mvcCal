﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace calculator.Models
{
    public class calculator
    {
        public double value1 { get; set; }
        public double value2 { get; set; }
        public double result { get; set; }
        public string opterator { get; set; }
        //public double Add ()
        //{
        //    return result = value1 + value2;

        //}
        //public double Sub()
        //{
        //    return result = value1 - value2;

        //}
    }
}
